#include<stdio.h>
#include<stdlib.h>

int main()
{
	printf("       A          N      N      DDDDDDDDD     Y       Y\n");
	printf("      A A         NN     N      D        D     Y     Y\n");
	printf("     A   A        N N    N      D         D     Y   Y \n");
	printf("    A     A       N  N   N      D         D      Y Y \n");
	printf("   AAAAAAAAA      N   N  N      D         D       Y\n");
	printf("  A         A     N    N N      D         D       Y\n");
	printf(" A           A    N     NN      D        D        Y\n");
	printf("A             A   N      N      DDDDDDDDD         Y\n");

}